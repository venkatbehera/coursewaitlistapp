namespace CourseWaitlist;

public enum EnrollmentStatus
{
    Enrolled,
    Waitlisted,
    AlreadyEnrolled,
    AlreadyWaitlisted,
    PrerequisiteNotMet,
    InvalidLearnerId,
    Dropped,
    NotEnrolled
}

public sealed record EnrollmentResult(
    EnrollmentStatus Status,
    string Message,
    string? PromotedLearnerId = null);

public sealed record CourseSnapshot(
    int Capacity,
    IReadOnlyList<string> EnrolledLearners,
    IReadOnlyList<string> WaitlistedLearners);

/// <summary>
/// Thread-safe, single-process implementation for one course offering.
/// The prerequisite delegate is evaluated while holding the service lock.
/// </summary>
public sealed class EnrollmentService
{
    private readonly object _gate = new();
    private readonly int _capacity;
    private readonly Func<string, bool> _meetsPrerequisite;
    private readonly HashSet<string> _enrolled = new(StringComparer.Ordinal);
    private readonly Dictionary<string, long> _waitlisted = new(StringComparer.Ordinal);
    private long _nextSequence;

    public EnrollmentService(int capacity, Func<string, bool> meetsPrerequisite)
    {
        if (capacity <= 0) throw new ArgumentOutOfRangeException(nameof(capacity), "Capacity must be greater than zero.");
        _capacity = capacity;
        _meetsPrerequisite = meetsPrerequisite ?? throw new ArgumentNullException(nameof(meetsPrerequisite));
    }

    public EnrollmentResult Enroll(string? learnerId)
    {
        if (string.IsNullOrWhiteSpace(learnerId))
            return new(EnrollmentStatus.InvalidLearnerId, "Learner ID is required.");

        learnerId = learnerId.Trim();
        lock (_gate)
        {
            if (_enrolled.Contains(learnerId))
                return new(EnrollmentStatus.AlreadyEnrolled, $"Learner '{learnerId}' is already enrolled.");
            if (_waitlisted.ContainsKey(learnerId))
                return new(EnrollmentStatus.AlreadyWaitlisted, $"Learner '{learnerId}' is already waitlisted.");
            if (!_meetsPrerequisite(learnerId))
                return new(EnrollmentStatus.PrerequisiteNotMet, $"Learner '{learnerId}' does not meet the prerequisite.");

            if (_enrolled.Count < _capacity)
            {
                _enrolled.Add(learnerId);
                return new(EnrollmentStatus.Enrolled, $"Learner '{learnerId}' enrolled successfully.");
            }

            _waitlisted.Add(learnerId, _nextSequence++);
            return new(EnrollmentStatus.Waitlisted, $"Course is full; learner '{learnerId}' was added to the waitlist.");
        }
    }

    public EnrollmentResult Drop(string? learnerId)
    {
        if (string.IsNullOrWhiteSpace(learnerId))
            return new(EnrollmentStatus.InvalidLearnerId, "Learner ID is required.");

        learnerId = learnerId.Trim();
        lock (_gate)
        {
            if (!_enrolled.Remove(learnerId))
                return new(EnrollmentStatus.NotEnrolled, $"Learner '{learnerId}' is not currently enrolled.");

            string? promoted = PromoteNextEligible();
            return new(EnrollmentStatus.Dropped,
                promoted is null
                    ? $"Learner '{learnerId}' was dropped; no eligible waitlisted learner was available."
                    : $"Learner '{learnerId}' was dropped; learner '{promoted}' was promoted.",
                promoted);
        }
    }

    public CourseSnapshot GetSnapshot()
    {
        lock (_gate)
        {
            return new CourseSnapshot(
                _capacity,
                _enrolled.OrderBy(x => x, StringComparer.Ordinal).ToArray(),
                _waitlisted.OrderBy(x => x.Value).Select(x => x.Key).ToArray());
        }
    }

    private string? PromoteNextEligible()
    {
        // Examine waitlisted learners in sequence order. Ineligible entries are retained,
        // but skipped for this promotion. The first eligible learner is removed and enrolled.
        foreach (var entry in _waitlisted.OrderBy(x => x.Value).ToArray())
        {
            if (_enrolled.Contains(entry.Key))
            {
                _waitlisted.Remove(entry.Key); // defensive cleanup of an impossible invalid state
                continue;
            }

            if (!_meetsPrerequisite(entry.Key))
                continue;

            _waitlisted.Remove(entry.Key);
            _enrolled.Add(entry.Key);
            return entry.Key;
        }

        return null;
    }
}
