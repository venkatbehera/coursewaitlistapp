using CourseWaitlist;

var eligibleLearners = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
{
    "alice", "bob", "carol", "dave"
};
var service = new EnrollmentService(capacity: 2, learnerId => eligibleLearners.Contains(learnerId));

Console.WriteLine("CourseWaitlist demo (commands: enroll <id>, drop <id>, status, quit)");
while (true)
{
    Console.Write("> ");
    var input = Console.ReadLine();
    if (input is null) break;
    var parts = input.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
    if (parts.Length == 0) continue;

    switch (parts[0].ToLowerInvariant())
    {
        case "quit": return;
        case "status":
            var snapshot = service.GetSnapshot();
            Console.WriteLine($"Capacity: {snapshot.EnrolledLearners.Count}/{snapshot.Capacity}");
            Console.WriteLine($"Enrolled: {(snapshot.EnrolledLearners.Count == 0 ? "(none)" : string.Join(", ", snapshot.EnrolledLearners))}");
            Console.WriteLine($"Waitlist: {(snapshot.WaitlistedLearners.Count == 0 ? "(empty)" : string.Join(", ", snapshot.WaitlistedLearners))}");
            break;
        case "enroll" when parts.Length == 2:
            Print(service.Enroll(parts[1]));
            break;
        case "drop" when parts.Length == 2:
            Print(service.Drop(parts[1]));
            break;
        default:
            Console.WriteLine("Usage: enroll <id> | drop <id> | status | quit");
            break;
    }
}

static void Print(EnrollmentResult result)
{
    Console.WriteLine($"{result.Status}: {result.Message}");
}
