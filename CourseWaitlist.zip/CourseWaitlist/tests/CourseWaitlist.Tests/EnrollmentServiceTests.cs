using CourseWaitlist;
using Xunit;

namespace CourseWaitlist.Tests;

public sealed class EnrollmentServiceTests
{
    private static EnrollmentService Create(int capacity = 2, params string[] eligible)
    {
        var eligibleSet = new HashSet<string>(eligible, StringComparer.Ordinal);
        return new EnrollmentService(capacity, id => eligibleSet.Contains(id));
    }

    [Fact]
    public void EnrollsWhenCapacityIsAvailable() 
    {
        var service = Create(2, "A", "B");
        Assert.Equal(EnrollmentStatus.Enrolled, service.Enroll("A").Status);
        Assert.Single(service.GetSnapshot().EnrolledLearners);
    }

    [Fact]
    public void AddsEligibleLearnerToWaitlistWhenFull()
    {
        var service = Create(1, "A", "B");
        service.Enroll("A");
        Assert.Equal(EnrollmentStatus.Waitlisted, service.Enroll("B").Status);
        Assert.Equal(new[] { "B" }, service.GetSnapshot().WaitlistedLearners);
    }

    [Fact]
    public void DuplicateEnrollRequestsDoNotCreateDuplicateRecords()
    {
        var service = Create(1, "A", "B");
        service.Enroll("A");
        Assert.Equal(EnrollmentStatus.AlreadyEnrolled, service.Enroll("A").Status);
        Assert.Equal(EnrollmentStatus.Waitlisted, service.Enroll("B").Status);
        Assert.Equal(EnrollmentStatus.AlreadyWaitlisted, service.Enroll("B").Status);
        Assert.Single(service.GetSnapshot().EnrolledLearners);
        Assert.Single(service.GetSnapshot().WaitlistedLearners);
    }

    [Fact]
    public void DropPromotesEarliestEligibleWaitlistedLearner()
    {
        var service = Create(1, "A", "B", "C");
        service.Enroll("A"); service.Enroll("B"); service.Enroll("C");
        var result = service.Drop("A");
        Assert.Equal(EnrollmentStatus.Dropped, result.Status);
        Assert.Equal("B", result.PromotedLearnerId);
        Assert.Equal(new[] { "B" }, service.GetSnapshot().EnrolledLearners);
        Assert.Equal(new[] { "C" }, service.GetSnapshot().WaitlistedLearners);
    }

    [Fact]
    public void RejectsLearnerWhoDoesNotMeetPrerequisite()
    {
        var service = Create(1, "A");
        Assert.Equal(EnrollmentStatus.PrerequisiteNotMet, service.Enroll("X").Status);
        Assert.Empty(service.GetSnapshot().EnrolledLearners);
        Assert.Empty(service.GetSnapshot().WaitlistedLearners);
    }

    [Fact]
    public void SkipsButRetainsWaitlistedLearnerWhoLaterBecomesIneligible()
    {
        var eligible = new HashSet<string>(new[] { "A", "B", "C" }, StringComparer.Ordinal);
        var service = new EnrollmentService(1, id => eligible.Contains(id));
        service.Enroll("A"); service.Enroll("B"); service.Enroll("C");
        eligible.Remove("B");

        var result = service.Drop("A");
        Assert.Equal("C", result.PromotedLearnerId);
        Assert.Equal(new[] { "B" }, service.GetSnapshot().WaitlistedLearners);
        Assert.Equal(new[] { "C" }, service.GetSnapshot().EnrolledLearners);
    }

    [Fact]
    public void InvalidAndRepeatedDropsDoNotChangeState()
    {
        var service = Create(1, "A");
        Assert.Equal(EnrollmentStatus.InvalidLearnerId, service.Drop(" ").Status);
        Assert.Equal(EnrollmentStatus.NotEnrolled, service.Drop("A").Status);
        service.Enroll("A");
        Assert.Equal(EnrollmentStatus.Dropped, service.Drop("A").Status);
        var before = service.GetSnapshot();
        Assert.Equal(EnrollmentStatus.NotEnrolled, service.Drop("A").Status);
        var after = service.GetSnapshot();
        Assert.Equal(before.Capacity, after.Capacity);
        Assert.Equal(before.EnrolledLearners, after.EnrolledLearners);
        Assert.Equal(before.WaitlistedLearners, after.WaitlistedLearners);
    }

    [Fact]
    public async Task ConcurrentEnrollmentsNeverExceedCapacityOrDuplicateLearners()
    {
        const int capacity = 10;
        var learners = Enumerable.Range(0, 100).Select(i => $"L{i}").ToArray();
        var service = Create(capacity, learners);
        var results = await Task.WhenAll(learners.Select(id => Task.Run(() => service.Enroll(id))));
        var snapshot = service.GetSnapshot();

        Assert.Equal(capacity, snapshot.EnrolledLearners.Count);
        Assert.Equal(learners.Length - capacity, snapshot.WaitlistedLearners.Count);
        Assert.Equal(learners.Length, snapshot.EnrolledLearners.Concat(snapshot.WaitlistedLearners).Distinct().Count());
        Assert.Equal(capacity, results.Count(r => r.Status == EnrollmentStatus.Enrolled));
        Assert.Equal(learners.Length - capacity, results.Count(r => r.Status == EnrollmentStatus.Waitlisted));
    }

    [Fact]
    public void RejectsInvalidCapacity()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new EnrollmentService(0, _ => true));
    }
}
